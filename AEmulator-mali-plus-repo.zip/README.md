# AEmulator mali+ (fork of AEmulator 0.0.0.3 by uxazu, GPL-3.0)

Copy `app/` from here over the unzipped `AEmulator-0.0.0.3/app/` (or `patch -p1 < AEmulator-mali-plus.patch` from the source root), then:

    ./gradlew assembleStandardRelease      # JDK 17, Android SDK 36, NDK r28

## Changes
- Name AEmulator mali+, package app.aemu.maliplus, version 0.0.0.3-mali+, orange default theme
- Fixed Install APK (core/ApkInstaller.kt)
- Ask AI why it crashed via OpenRouter (key + model in App settings)
- Mali boost (core/MaliTuning.kt), toggle in App settings
- Settings: creator section - Author Pixel8protech, Telegram @Pixel8protech (t.me/Pixel8protech), GitHub @pegiooos; original author uxazu stays credited
- Upstream auto-update check off by default

Based on AEmulator by uxazu (https://github.com/uxazu/AEmulator), GPL-3.0. This fork must stay GPL-3.0 and publish its source.
