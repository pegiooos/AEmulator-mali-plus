package app.aemu.core

import android.os.Build

/** AEmulator mali+: the text sent to the AI when the user asks why the system crashed. */
object CrashReport {
    fun build(vm: GuestVm, extra: String? = null): String {
        val sb = StringBuilder()
        sb.append("Phone: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT}), ")
            .append("SoC ${if (Build.VERSION.SDK_INT >= 31) Build.SOC_MODEL else Build.HARDWARE}, GPU driver '${HostInfo.gpu()}'\n")
        sb.append("Guest: ${vm.img.name}, ${vm.img.displayVersion}, engine ${vm.engine}\n")
        sb.append("State: ${vm.state}\n")
        vm.failure?.let { sb.append("Failure: $it\n") }
        extra?.let { sb.append("Extra: $it\n") }
        sb.append("\n--- app log (last 120 lines) ---\n")
        vm.lines().takeLast(120).forEach { sb.append(it.take(400)).append('\n') }
        val guest = runCatching { GuestLog.tail(vm.paths.root, 128 * 1024) }.getOrDefault(emptyList())
            .filter { it.prio in "EFW" }.takeLast(60)
        if (guest.isNotEmpty()) {
            sb.append("\n--- guest logcat warnings/errors (last ${guest.size}) ---\n")
            guest.forEach { sb.append("${it.prio}/${it.tag}: ${it.msg.take(300)}\n") }
        }
        return sb.toString().takeLast(24_000)
    }
}
