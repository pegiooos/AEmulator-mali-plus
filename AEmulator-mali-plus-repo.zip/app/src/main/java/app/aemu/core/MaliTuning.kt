package app.aemu.core

import android.app.Activity
import android.content.Context
import android.os.Build
import android.os.PowerManager
import android.view.Surface

/**
 * AEmulator mali+: a small, safe Mali boost. It never touches the GL bridge or the guest engine itself:
 *  - sustained performance mode: the phone keeps a steady GPU/CPU clock instead of boosting and then throttling
 *  - frame-rate hint: the emulator surface asks the compositor for the guest's refresh rate (60 Hz) instead of the
 *    phone's 90/120 Hz, which cuts the GPU work of the final composition
 * Both are reversible and only used on Mali (or when forced on in settings).
 */
object MaliTuning {
    fun isMali(): Boolean = HostInfo.gpu().contains("mali")

    /** setting "Mali boost": automatic default = on for Mali phones */
    fun enabled(ctx: Context): Boolean =
        app.aemu.AppPrefs.prefs(ctx).getBoolean("mali_boost", isMali())

    fun setEnabled(ctx: Context, v: Boolean) = app.aemu.AppPrefs.prefs(ctx).edit().putBoolean("mali_boost", v).apply()

    fun applyWindow(a: Activity, log: (String) -> Unit) {
        if (!enabled(a)) return
        if (Build.VERSION.SDK_INT >= 24) {
            val pm = a.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (pm.isSustainedPerformanceModeSupported) {
                runCatching { a.window.setSustainedPerformanceMode(true); log("Mali boost: sustained performance mode on") }
            }
        }
    }

    fun hintSurface(s: Surface?, ctx: Context, hz: Int) {
        if (s == null || !s.isValid || Build.VERSION.SDK_INT < 30 || !enabled(ctx)) return
        runCatching { s.setFrameRate(hz.toFloat().coerceIn(24f, 120f), Surface.FRAME_RATE_COMPATIBILITY_DEFAULT) }
    }
}
