package app.aemu.core

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** AEmulator mali+: "ask AI why it crashed" through OpenRouter. Runs only when the user taps the button. */
object OpenRouter {
    const val KEY_NAME = "openrouter"
    const val DEFAULT_MODEL = "openrouter/auto"
    private const val URL_CHAT = "https://openrouter.ai/api/v1/chat/completions"

    fun apiKey(ctx: Context) = SecretStore.get(ctx, KEY_NAME)
    fun setApiKey(ctx: Context, key: String) = SecretStore.put(ctx, KEY_NAME, key.trim())
    fun model(ctx: Context): String =
        app.aemu.AppPrefs.prefs(ctx).getString("or_model", DEFAULT_MODEL)?.ifBlank { DEFAULT_MODEL } ?: DEFAULT_MODEL
    fun setModel(ctx: Context, m: String) = app.aemu.AppPrefs.prefs(ctx).edit().putString("or_model", m.trim()).apply()

    private const val SYSTEM = "You are a debugging assistant inside AEmulator, an Android app that runs old Android firmware " +
        "(2.3–17) on a phone through QEMU/a native engine. You get the failure message, the app log and the guest logcat. " +
        "Explain in plain language: (1) the most likely root cause, (2) the evidence from the log lines (quote them), " +
        "(3) concrete things the user can try in the app settings (RAM, GPU/hwui, JIT, 32-bit mode, resolution) or with the firmware. " +
        "If the log is not enough to be sure, say so. Keep it short."

    /** Blocking; call off the main thread. Throws with a readable message on failure. */
    fun ask(ctx: Context, report: String): String {
        val key = apiKey(ctx)
        require(key.isNotBlank()) { "No OpenRouter API key. Add it in the app settings." }
        val body = JSONObject()
            .put("model", model(ctx))
            .put("max_tokens", 900)
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", SYSTEM))
                .put(JSONObject().put("role", "user").put("content", report)))
        val c = (URL(URL_CHAT).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 15_000; readTimeout = 90_000; doOutput = true
            setRequestProperty("Authorization", "Bearer $key")
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("X-Title", "AEmulator mali+")
        }
        try {
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val msg = runCatching { JSONObject(text).getJSONObject("error").getString("message") }.getOrDefault(text.take(300))
                error("OpenRouter HTTP $code: $msg")
            }
            return JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
        } finally { c.disconnect() }
    }
}
