package app.aemu.core

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.zip.ZipInputStream

/**
 * AEmulator mali+: fixed "Install APK". The old flow copied the file to one fixed name and ran a bare `pm install -r`:
 * a failure was reduced to the last line, split APKs / .xapk / .apks were not supported, the temp file stayed on the card,
 * and downgrades / test-only APKs failed with no way to see why. This version:
 *  - copies under a unique name and always cleans it up
 *  - supports .apk and bundles (.apks / .xapk / .apkm / zip with several .apk) through a pm install session (5.0+)
 *  - retries with -d (allow downgrade) and -t (test APKs) when the first try is refused for that reason
 *  - returns the whole pm output, so the AI crash analyzer or the user can read the real error
 */
object ApkInstaller {
    data class Result(val ok: Boolean, val message: String)

    fun install(ctx: Context, vm: GuestVm, uri: Uri, displayName: String?): Result {
        val dir = Sdcard.hostDir(vm.paths) ?: return Result(false, "The shared card folder is not available (start the system first)")
        val work = File(dir, "aemu-inst-${System.currentTimeMillis()}").apply { mkdirs() }
        val card = vm.img.sdcardPath.trimEnd('/') + "/" + work.name
        try {
            val name = displayName.orEmpty().lowercase()
            val isBundle = name.endsWith(".apks") || name.endsWith(".xapk") || name.endsWith(".apkm") || name.endsWith(".zip")
            val files = ArrayList<File>()
            if (isBundle) {
                ctx.contentResolver.openInputStream(uri)!!.use { raw ->
                    ZipInputStream(raw).use { z ->
                        while (true) {
                            val e = z.nextEntry ?: break
                            // only top-level .apk files; the name is flattened, so a crafted zip cannot write elsewhere
                            if (e.isDirectory || !e.name.lowercase().endsWith(".apk")) continue
                            val f = File(work, "p${files.size}_" + e.name.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_"))
                            f.outputStream().use { z.copyTo(it) }; files.add(f)
                        }
                    }
                }
                if (files.isEmpty()) return Result(false, "No .apk files inside this archive")
            } else {
                val f = File(work, "base.apk")
                ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { i.copyTo(it) } }
                files.add(f)
            }
            if (files.any { it.length() < 1000 }) return Result(false, "The file is empty or damaged")
            val grant = if (vm.img.api >= 23) " -g" else ""
            val out = if (files.size == 1) {
                var o = vm.guestShell("pm install -r$grant $card/${files[0].name} 2>&1", 300_000)
                if (!o.contains("Success")) {
                    val extra = StringBuilder()
                    if (o.contains("VERSION_DOWNGRADE") || o.contains("downgrade", true)) extra.append(" -d")
                    if (o.contains("INSTALL_FAILED_TEST_ONLY")) extra.append(" -t")
                    if (extra.isNotEmpty()) o += "\n--- retry with$extra ---\n" +
                        vm.guestShell("pm install -r$grant$extra $card/${files[0].name} 2>&1", 300_000)
                }
                o
            } else {
                if (vm.img.api < 21) return Result(false, "Split APKs need Android 5.0 or newer in the guest")
                val total = files.sumOf { it.length() }
                val create = vm.guestShell("pm install-create -r$grant -S $total 2>&1", 60_000)
                val id = Regex("\\[(\\d+)]").find(create)?.groupValues?.get(1) ?: return Result(false, "pm install-create failed:\n$create")
                val sb = StringBuilder()
                for (f in files) sb.append(vm.guestShell("pm install-write -S ${f.length()} $id ${f.name} $card/${f.name} 2>&1", 300_000)).append('\n')
                sb.append(vm.guestShell("pm install-commit $id 2>&1", 300_000)); sb.toString()
            }
            runCatching { TreeFixer(ctx, vm.paths, vm.img, vm::log).seedOwners() }
            val ok = out.contains("Success")
            return Result(ok, out.trim().lines().filter { it.isNotBlank() }.takeLast(12).joinToString("\n").ifBlank { "No output from pm" })
        } catch (t: Throwable) {
            return Result(false, t.toString())
        } finally {
            runCatching { work.deleteRecursively() }
        }
    }
}
