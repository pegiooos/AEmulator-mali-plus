package app.aemu.ui

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.MotionScheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// AEmulator mali+: orange default theme (primary #FF6D00) with Material 3 tones
private val Light = lightColorScheme(
    primary = Color(0xFFB34700), onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDBC8), onPrimaryContainer = Color(0xFF351000),
    secondary = Color(0xFF765848), onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFDBC8), onSecondaryContainer = Color(0xFF2B160A),
    tertiary = Color(0xFF686014), onTertiary = Color.White,
    tertiaryContainer = Color(0xFFF0E58C), onTertiaryContainer = Color(0xFF1F1C00),
    background = Color(0xFFFFF8F5), surface = Color(0xFFFFF8F5),
    surfaceContainer = Color(0xFFFCEAE0), surfaceContainerHigh = Color(0xFFF6E4DA),
    surfaceContainerHighest = Color(0xFFF0DED5), surfaceContainerLow = Color(0xFFFFF1EA),
    error = Color(0xFFBA1A1A),
)

private val Dark = darkColorScheme(
    primary = Color(0xFFFFB68F), onPrimary = Color(0xFF572000),
    primaryContainer = Color(0xFFFF6D00), onPrimaryContainer = Color(0xFF2A0D00),
    secondary = Color(0xFFE6BEAA), onSecondary = Color(0xFF442A1C),
    secondaryContainer = Color(0xFF5D4031), onSecondaryContainer = Color(0xFFFFDBC8),
    tertiary = Color(0xFFD3C973), onTertiary = Color(0xFF353100),
    tertiaryContainer = Color(0xFF4E4800), onTertiaryContainer = Color(0xFFF0E58C),
    background = Color(0xFF17120F), surface = Color(0xFF17120F),
    surfaceContainer = Color(0xFF241E1A), surfaceContainerHigh = Color(0xFF2F2824),
    surfaceContainerHighest = Color(0xFF3A332F), surfaceContainerLow = Color(0xFF1F1A16),
)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(36.dp),
)

private val base = Typography()
private val AppType = base.copy(
    displaySmall = base.displaySmall.copy(fontWeight = FontWeight.SemiBold),
    headlineLarge = base.headlineLarge.copy(fontWeight = FontWeight.SemiBold, letterSpacing = (-0.5).sp),
    headlineMedium = base.headlineMedium.copy(fontWeight = FontWeight.SemiBold),
    titleLarge = base.titleLarge.copy(fontWeight = FontWeight.SemiBold),
    labelLarge = base.labelLarge.copy(fontWeight = FontWeight.SemiBold),
)

@Composable
fun AemuTheme(forceDark: Boolean? = null, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    // the main screen stays alive while the settings screen changes the theme: follow the stored value
    val rev = androidx.compose.runtime.remember { androidx.compose.runtime.mutableIntStateOf(0) }
    androidx.compose.runtime.DisposableEffect(ctx) {
        val sp = app.aemu.AppPrefs.prefs(ctx)
        val l = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> rev.intValue++ }
        sp.registerOnSharedPreferenceChangeListener(l)
        onDispose { sp.unregisterOnSharedPreferenceChangeListener(l) }
    }
    rev.intValue
    val dark = forceDark ?: when (app.aemu.AppPrefs.theme(ctx)) {
        app.aemu.AppPrefs.THEME_LIGHT -> false
        app.aemu.AppPrefs.THEME_DARK -> true
        else -> isSystemInDarkTheme()
    }
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 && app.aemu.AppPrefs.dynamicColor(ctx) -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> Dark
        else -> Light
    }
    MaterialExpressiveTheme(
        colorScheme = scheme,
        motionScheme = MotionScheme.expressive(),
        shapes = AppShapes,
        typography = AppType,
        content = content,
    )
}

val Mono = TextStyle(fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, fontSize = 11.sp, lineHeight = 14.sp)
